/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package football;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 *
 * @author 5KullcRacK3r
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button select_form;
    @FXML
    private Button player_1;
    @FXML
    private Button player_2;
    @FXML
    private Button player_3;
    @FXML
    private Button player_4;
    @FXML
    private Button player_5;
    @FXML
    private Button player_6;
    @FXML
    private Button player_7;
    @FXML
    private Button player_8;
    @FXML
    private Button player_9;
    @FXML
    private Button player_10;
    @FXML
    private Button player_11;
    private ArrayList<Button> Formation_List;
    @FXML
    private Label score;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Formation_List = new ArrayList<Button>(Arrays.asList(player_1, player_2, 
        player_3, player_4, player_5, player_6, player_7, player_8, player_9, player_10, player_11)); 
    }
    public Button getSelect(){
        return select_form;
    }
    public ArrayList<Button> getPlayerList(){
        return Formation_List;
    }
    public Label getScore(){
        return score;
    }

}
