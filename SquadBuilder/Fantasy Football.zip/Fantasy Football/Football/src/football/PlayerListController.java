/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package football;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author 5KullcRacK3r
 */
public class PlayerListController implements Initializable {
    @FXML
    private TableView<Player> player_list;
    @FXML
    private TableColumn<Player, String> name;
    @FXML
    private TableColumn<Player, String> country;
    @FXML
    private TableColumn<Player, String> rating;
    @FXML
    private TableColumn<Player, String> club;
    @FXML
    private TableColumn<Player, String> position;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Label ph = new Label("Players Not Available");
        player_list.setPlaceholder(ph);
        name.setCellValueFactory(new PropertyValueFactory<Player, String>("Name"));
        country.setCellValueFactory(new PropertyValueFactory<Player, String>("Country"));
        club.setCellValueFactory(new PropertyValueFactory<Player, String>("Club"));
        rating.setCellValueFactory(new PropertyValueFactory<Player, String>("Rating"));
        position.setCellValueFactory(new PropertyValueFactory<Player, String>("Position"));

    }
    public TableView<Player> getPlayers(){
        return player_list;
    }
}
