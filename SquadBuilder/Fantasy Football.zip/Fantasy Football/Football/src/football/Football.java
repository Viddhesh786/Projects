/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package football;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableRow;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author 5KullcRacK3r
 */
public class Football extends Application {

    FXMLDocumentController c;
    FormationController f;
    PlayerListController p;
    Statement stmt;
    ResultSet rs;
    Connection conn;
    ArrayList<String> player_names = new ArrayList<String>();
    StringBuilder already_selected = new StringBuilder("\'\'");
    int score[] = new int[11];
    String country[] = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"};
    String club[] = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"};
    private static int ctr = 0;
    int new_score = 0;
    double player_xy[][] = new double[11][2];

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FXMLDocument.fxml"));
        Parent root = loader.load();
        c = (FXMLDocumentController) loader.getController();
        String dbURL = "jdbc:derby://localhost:1527/somshing";
        String user = "vidyesh";
        String password = "9890864644";
        conn = DriverManager.getConnection(dbURL, user, password);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        initialize_buttons(442);
    }

    public void reinit(String[] country, String[] club, int[] score) {
        for (int i = 0; i < 11; i++) {
            country[i] = String.valueOf(i + 1);
            club[i] = String.valueOf(i + 1);
            score[i] = 0;
        }
    }

    public void change_form(Stage stage, int form) {
        FXMLLoader loader = new FXMLLoader();
        new_score = 0;
        reinit(country, club, score);
        if (form == 433) {
            loader.setLocation(getClass().getResource("433.fxml"));
        } else if (form == 451) {
            loader.setLocation(getClass().getResource("451.fxml"));
        } else if (form == 442) {
            loader.setLocation(getClass().getResource("FXMLDocument.fxml"));
        }
        Parent root = null;
        try {
            root = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        c = (FXMLDocumentController) loader.getController();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        initialize_buttons(form);
    }

    void initialize_buttons(int formation) {
        int i = 0;

        for (Button player : c.getPlayerList()) {
            player_xy[i][0] = player.getLayoutX();
            player_xy[i][1] = player.getLayoutY();
            player.setOnMouseClicked(event -> {
                AnchorPane root1 = null;
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/football/Resources/PlayerList.fxml"));
                try {
                    root1 = loader.load();
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
                p = (PlayerListController) loader.getController();
                Stage player_select = new Stage();
                player_select.initModality(Modality.APPLICATION_MODAL);
                player_select.setTitle("Select a Player");
                player_select.setScene(new Scene(root1));
                player_select.show();
                //TODO: if 0 for every key "goalie" load in table name country and score if 0<i<first_num_form for every key "defender" load in table etc 
                try {

                    stmt = conn.createStatement();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
//                if(ctr==0)
//                {
//                    rs.
//                }
//               
                List<Player> players = new ArrayList<Player>();
                System.out.println(formation / 100 + " " + ctr);
                int player_index = c.getPlayerList().indexOf(player);
                for (String name : player_names) {

                    already_selected.append(", \'" + name + "\'");
                }
                if (!already_selected.equals("")) {
                    already_selected.substring(0, already_selected.length() - 2);
                }
                if (player_index == 0) {
                    populate_players_table("SELECT * FROM VIDYESH.FUT_PLAYERS WHERE (POSITION = 'GK') and NOT NAME IN (" + already_selected + ")", players);
                } else if (player_index > 0 && player_index <= formation / 100) {
                    populate_players_table("SELECT * FROM VIDYESH.FUT_PLAYERS WHERE (POSITION = 'CB' or POSITION = 'RB' or POSITION = 'LB') and NOT NAME IN (" + already_selected + ")", players);

                } else if (player_index > formation / 100 && player_index <= (formation / 100 + (formation / 10) % 10)) {
                    populate_players_table("SELECT * FROM VIDYESH.FUT_PLAYERS WHERE (POSITION = 'CM' or POSITION = 'CAM' or POSITION = 'LM' or POSITION = 'CDM')and NOT NAME IN (" + already_selected + ")", players);

                } else if (player_index > (formation / 100 + (formation / 10) % 10) && player_index <= (formation / 100 + (formation / 10) % 10 + formation % 10)) {
                    populate_players_table("SELECT * FROM VIDYESH.FUT_PLAYERS WHERE (POSITION = 'CF' or POSITION = 'LW' or POSITION = 'RW' or POSITION = 'ST') and NOT NAME IN (" + already_selected + ")", players);

                }

                ObservableList<Player> items = FXCollections.observableArrayList(players);
                p.getPlayers().setItems(items);
                p.getPlayers().setRowFactory(tv -> {
                    TableRow<Player> row = new TableRow<>();
                    row.setOnMouseClicked(event2 -> {
                        if (event2.getClickCount() == 2 && (!row.isEmpty())) {
                            graph g = new graph(formation);
                            score[player_index] = Integer.parseInt(row.getItem().RatingProperty().getValue());
                            country[player_index] = row.getItem().CountryProperty().getValue();
                            club[player_index] = row.getItem().ClubProperty().getValue();
                            String name = row.getItem().NameProperty().getValue();
                            player_names.add(name);
                            g.find_distance();
                            new_score = (int) g.score(score, country, club, 20);
                            c.getScore().setText("Total Score: " + String.valueOf(new_score));
                            String resource_loc = getClass().getResource("/football/Resources/players/" + name + ".png").toString();
                            player.setStyle("-fx-background-image: url(" + resource_loc + ");");
                            player_select.close();

                        }
                    });
                    return row;
                });
            });
        }

        c.getSelect()
                .setOnMouseClicked(event -> {
                    AnchorPane root1 = null;
                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("/football/Resources/select_formation.fxml"));
                    try {
                        root1 = loader.load();
                    } catch (IOException ex) {
                        Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    f = (FormationController) loader.getController();
                    Stage select_stage = new Stage();
                    select_stage.initModality(Modality.APPLICATION_MODAL);
                    select_stage.setTitle("Select Formation");
                    select_stage.setScene(new Scene(root1));
                    select_stage.show();
                    Stage back_stage = (Stage) c.getSelect().getScene().getWindow();
                    f.getfourfourtwo().setOnMouseClicked(event2 -> {
                        change_form(back_stage, 442);
                    });
                    f.getfourthreethree().setOnMouseClicked(event2 -> {
                        change_form(back_stage, 433);
                    });
                    f.getfourfiveone().setOnMouseClicked(event2 -> {
                        change_form(back_stage, 451);
                    });

                }
                );

    }

    public void populate_players_table(String sql, List<Player> players) {
        try {
            ArrayList<Player> all = new ArrayList<>();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String rating = String.valueOf(rs.getInt("RATING"));
                String name = rs.getString("NAME");
                String club = rs.getString("CLUB");
                String country = rs.getString("COUNTRY");
                String position = rs.getString("POSITION");
                all.add(new Player(name, country, club, rating, position));
//                            players[rs.getRow()] = new Player(name, country, club, rating, position);
            }
            Random rand = new Random();
            for (int i = 0; i < 5; i++) {
                int rand_index = rand.nextInt(all.size());
                players.add(all.get(rand_index));
                all.remove(rand_index);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    Line init_lines(double player_xy[][])
//    {
//        int player_line_count[] = new int[11];
//        node temp = null;
//        for(int i=0; i<11; i++)
//        {
//            temp = head[i]; //Line originating Player
//            while(temp!=null)
//            {
//                int data = temp.data; //Line terminating Player
//                if(player_line_count[data]==0)
//                    player_line_count[data]++;
//                else
//                {
//                    player_line_count[data]--;
//                    temp = temp.next;
//                    continue;
//                }
//            double card_width = getPlayerList().get(0).getWidth();
//            double card_height = getPlayerList().get(0).getHeight();
//            double start_x = 367 + card_width/2;
//            double start_y = 20 + card_height/2;
//            double end_x = 126 + card_width/2;
//            double end_y = 159 + card_height/2;
//            Line line = new Line(start_x, start_y, end_x, end_y);
//            line.setLayoutX(0);line.setLayoutY(0);
//            line.toBack();
//            Paint redColor = Color.RED;
//            line.setStroke(redColor);
//            }
//        }
//    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
