/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package football;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 *
 * @author 5KullcRacK3r
 */
public class FormationController implements Initializable {
    @FXML
    private Button fourfourtwo;
    @FXML
    private Button fourthreethree;
    @FXML
    private Button fourfiveone;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
    public Button getfourfourtwo(){
        return fourfourtwo;
    }
    public Button getfourthreethree(){
        return fourthreethree;
    }
    public Button getfourfiveone(){
        return fourfiveone;
    }
}
