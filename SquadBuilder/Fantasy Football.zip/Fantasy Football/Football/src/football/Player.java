/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package football;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author 5KullcRacK3r
 */
public class Player {
    
    private StringProperty Name;
    private StringProperty Country;
    private StringProperty Club;
    private StringProperty Rating;
    private StringProperty Position;
    public Player(String name, String country, String club, String rating, String position)
    {
        this.Name = new SimpleStringProperty(name);
        this.Country = new SimpleStringProperty(country);
        this.Rating = new SimpleStringProperty(rating);
        this.Position = new SimpleStringProperty(position);
        this.Club = new SimpleStringProperty(club);
    }
    public StringProperty NameProperty(){
        return Name;
    }
    public StringProperty CountryProperty(){
        return Country;
    }
    public StringProperty RatingProperty(){
        return Rating;
    }
    public StringProperty PositionProperty(){
        return Position;
    }
    public StringProperty ClubProperty(){
        return Club;
    }
    
}
