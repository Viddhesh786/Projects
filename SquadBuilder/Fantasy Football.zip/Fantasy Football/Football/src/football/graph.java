package football;


import java.io.*;
import java.util.*;

public class graph
  {
  int distance[][] = new int[11][11];
  int mat[][];
  graph(int choice)
  {
  switch(choice)
  {
  case 433 :
           mat =   new int[][]{{0,1,1,1,1,0,0,0,0,0,0},
                   {1,0,1,0,0,1,1,0,0,0,0},
                   {1,1,0,1,0,1,1,0,0,0,0},
                   {1,0,1,0,1,0,1,1,0,0,0},
                   {1,0,0,1,0,0,1,1,0,0,0},
                   {0,1,1,0,0,0,1,0,1,1,0},
                   {0,0,1,1,1,1,0,1,1,1,1},
                   {0,0,0,1,1,0,1,0,0,1,1},
                   {0,0,0,0,0,1,1,0,0,1,0},
                   {0,0,0,0,0,1,1,1,1,0,1},
                   {0,0,0,0,0,0,1,1,0,1,0}};  //4-4-3
                    break;
  case 451 :
      mat = new int[][]{{0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0},
      {1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0},
      {1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0},
      {1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0},
      {1, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0},
      {0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1},
      {0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1},
      {0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1},
      {0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1},
      {0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1},
      {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0}}; //4-5-1
            break;
  case 442 :
      mat = new int[][]{{0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0},
      {1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0},
      {1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0},
      {1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0},
      {1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0},
      {0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0},
      {0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1},
      {0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1},
      {0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1},
      {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1},
      {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0}};   //4-4-2
            break;

    default : System.out.println("Invalid option");

  }
  }

  void BFS(int source)
    {
    int num = 0;
    int size = 11;
    int visited[] = new int[size];
    for(int i=0;i<size;i++)
      {
      distance[source][i]=-1;
      visited[i]=0;
      }
    LinkedList<Integer>queue = new LinkedList<>();
    queue.add(source);
    visited[source] = 1;
    distance[source][source] = 0;
    while(!queue.isEmpty())
      {
      int temp = queue.removeFirst();
        for(int i=0;i<size;i++)
          {
          if(mat[temp][i]==1 && visited[i]!=1)
            {
            queue.add(i);
            visited[i] = 1;
            distance[source][i] = distance[source][temp]+1;
            }
          }
      }
    }
void find_distance()
  {
    for(int i=0;i<11;i++)
      {
        BFS(i);
      }
  }
float score(int player[], String country[], String club[], int c)
  {
    int i,j,co=0,cl=0;
    float score=0;
    for(i=0;i<11;i++)
      {
        for(j=0;j<11;j++)
          {
            if(i!=j)
              {
              if(country[i].equals(country[j]))
                {
                  co=1;
                }
              if(club[i].equals(club[j]))
                {
                  cl=1;
                }
              score = score + (1/distance[i][j])*(c*co + c*cl + c*co*cl + player[i]);
              }
          }
      }
return score;
  }
    }


///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package football;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Queue;
//
///**
// *
// * @author 5KullcRacK3r
// */
//public class BFS_optim {
//    
//    private int V = 5;   // No. of vertices 
//    static int[][] a = new int[][]{
//        {0,0,0,0,1},
//        {0,0,1,1,0},
//        {0,1,1,0,1},
//        {1,0,1,0,0},
//        {1,0,0,0,0}
//    };
//    int [][] d = new int[V][V];
//    static boolean visited[];
//    static Queue q=new LinkedList<Integer>();
//    BFS_optim()
//    {
//    }
//    void BFS(int s)
//    {
//        visited = new boolean[V]; 
//        visited[s] = true;
//        q.add(s);
//        
//        while(q.size()!=0)
//        {
//            s = (int) q.poll();
//            System.out.println(s+ " ");
//            for(int i=0; i < V; i++)
//            {
//                if(!visited[i])
//                {
//                    a[s][i] = 
//                }
//            }
//        }
//        
//        
//    }
//    
//}